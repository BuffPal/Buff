<article class="container-fluid">
    <div class="box">
            <?php /*判断是否有图片*/ if( $src = get_head_image(get_the_content())): ?>
                <div class="container-fluid content-image-box">
                    <a href="<?php esc_url(the_permalink()) ?>"><img src="<?php echo $src ?>" id="img_img"/></a>
                    <div id="img_title">
                        <a href="<?php esc_url(the_permalink()) ?>"><?php the_title() ?></a>
                    </div>
                    <ul class="img_info">
                        <?php  echo get_post_info() ?>
                    </ul>
                </div>
            <?php endif; ?>
    </div>
</article>