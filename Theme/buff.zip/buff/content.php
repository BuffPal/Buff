<article class="container-fluid">
    <h2 class="post_title text-left">
        <a href="<?php echo esc_url(the_permalink()) ?> ">
            <?php the_title() ?>
        </a>
    </h2>
    <ul class="info">
        <?php  echo get_post_info() ?>
    </ul>
    <div class="box">
        <div class="container-fluid thumb">
            <?php /*判断是否有缩略图*/ if(has_post_thumbnail()): ?>

                <?php the_post_thumbnail('buff-entry-thumb'); ?>

                <div class="share container-fluid">
                    <div class="post-deco container-fluid">
                        <div class="hex hex-small">
                            <div class="hex-inner">
                                <a href="/" class="sharea">
                                    <i class="glyphicon glyphicon-send"></i>
                                </a>
                            </div>
                            <div class="corner-1"></div>
                            <div class="corner-2"></div>
                        </div>
                    </div>
                </div>
                
            <?php endif; ?>
        </div>
        <div class="container-fluid post_content">
            <?php the_excerpt() ?>
        </div>
        <!--TAG-->
        <div class="container-fluid tagWamp">
            <?php echo get_the_category_list(' '); ?>
        </div>
        <div class="more container-fluid">
            <div class="morebox">
                <a href="#" class="text-center">更多</a>
            </div>
        </div>
        <div class="footer"></div>
    </div>
</article>