<article class="container-fluid">
    <div class="box">
        <div class="row">
            <div class="col-md-3 audiothumb">
                <?php /*判断是否有缩略图*/
                if (has_post_thumbnail()): ?>
                    <a href="<?php the_permalink() ?>"><?php the_post_thumbnail('buff-entry-thumb'); ?></a>
                <?php endif; ?>
            </div>
            <div class="col-md-9">
                <div class="container-fluid text-left" style="padding: 0;">
                    <div class="col-md-11" style="padding: 0;">
                        <a href="<?php the_permalink() ?>" id="audioLink"><?php the_title() ?></a>
                    </div>
                    <div class="col-md-1" style="padding: 0;">
                        <div class="audioicon">
                            <a href="#"><i class="glyphicon glyphicon-music"></i></a>
                        </div>
                    </div>
                </div>
                <div class="container-fluid text-center" id="audio-excerpt">
                    <?php the_excerpt(); ?>
                </div>
                <ul class="info">
                    <?php echo get_post_info() ?>
                </ul>
            </div>
        </div>
        <div class="container-fluid audiogo">
            <?php the_content() ?>
        </div>
    </div>
</article>