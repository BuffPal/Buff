$(function(){
    /**
     * 顶部头像,打字动画
     */
    var oIWamp = $('#inputWamp');
    var sWamp = $.trim(oIWamp.html());
    var sDescription = $.trim($('input[name=description]').val());
    var slD = sDescription.length;
    var slW = sWamp.length;
    var arr = [];
    for( var i = 0 ; i < slD ; i++){
        arr[i] = sDescription.substr( i , 1 );
    }
    var t = -10;
    var w = 0;



    var sc = setInterval(sc,200);
    function sc(){
        //执行删减
        if(t < slW+1){
            html=sWamp.substring(0,slW-t);
            oIWamp.html(html);
            t++;
        }else{
            //清楚自己
            clearInterval(sc);
            //开始添加
           setInterval(go,180);
        }
    };

    function go(){
        if(w < slD){
            oIWamp.append(arr[w]);
            w++;
        }else{
            clearInterval();
        }
    }


    /**
     * 侧边栏固定
     */
    $("#sdb").pin({
        minWidth: 940
    })

});


