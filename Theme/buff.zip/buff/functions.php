<?php
date_default_timezone_set('Asia/Shanghai');
function p($arr){
    echo '<pre>';
    print_r($arr);
    die;
}
/**
 * 文章格式分类
 */
add_theme_support( 'post-formats', array(
    'image', 'video', 'audio', 'quote', 'link',
) );
//给文章设置缩略图
add_theme_support( 'post-thumbnails' );
//缩略图大小 控制
add_image_size('buff-entry-thumb', 750);


//注册一个小工具
register_sidebar(
    array(
        'id' => 'sidebar-1',
		'name'	=>		'侧边栏',		//工具名称
		'before_widget'	=>		'<div class=“sbox”>',     //以这个为包裹的开头
		'after_widget'	=>		'</div>',    //以这个为包裹的闭合
		'before_title'	=>		'<h2>',    //包裹内标题以这个为开头
		'after_title'	=>		'</h2>',  //同上以这个为结尾
	)
);

















//引入自定义主题工具
include_once(TEMPLATEPATH . '/inc/banner.php');
//引入文章信息 get_post_info
include_once(TEMPLATEPATH . '/inc/get_post_info.php');
//引入文章信息 小工具
include_once(TEMPLATEPATH . '/inc/tool.php');
//引入评论callback函数
include_once(TEMPLATEPATH . '/inc/buff_list_comments.php');

//添加自定义栏目
function sg_customize_register( $wp_customize ) {
    /**
     * 作者头像
     */
    $wp_customize->add_setting('author_pic', array(
        //默认图片
        'default' => get_template_directory_uri().'/images/author.jpg',
        //访问权限
        'capability' => 'edit_theme_options',
        //回调函数(不知道怎么用)
        'sanitize_callback' => 'esc_url_raw'
    ));

    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'author_pic', array(
        //标题名
        'label' => '头像',
        //所属栏目(放在哪个栏目里面)
        'section' => 'header_image',
        //排行(越小越前)
        'priority' => 4,
        //关联注册ID add_settiong
        'settings' => 'author_pic'
    )));

    /**
     * 作者鼠标放上颜色
     */
    $wp_customize->add_setting( 'buff_author_color', array(
        'default'        => '#ff4400',
        'type'           => 'theme_mod',
        'capability'     => 'edit_theme_options',
        'transport'      => 'refresh'
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'buff_author_color', array(
        'label'        => '作者头像触发阴影颜色',
        'section'    => 'header_image',
        'priority' => 5,
        'settings'   => 'buff_author_color',
    ) ) );

    /**
     * 滚动文字
     */
    $wp_customize->add_setting( 'buff_gundong_color', array(
        'default'        => '#ffffff',
        'type'           => 'theme_mod',
        'capability'     => 'edit_theme_options',
        'transport'      => 'refresh'
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'buff_gundong_color', array(
        'label'        => '滚动字体颜色',
        'section'    => 'header_image',
        'priority' => 6,
        'settings'   => 'buff_gundong_color',
    ) ) );


    /**
     * 滚动文字阴影
     */
    $wp_customize->add_setting( 'buff_gundong_shadow_color', array(
        'default'        => '#000000',
        'type'           => 'theme_mod',
        'capability'     => 'edit_theme_options',
        'transport'      => 'refresh'
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'buff_gundong_shadow_color', array(
        'label'        => '滚动字体阴影颜色',
        'section'    => 'header_image',
        'priority' => 7,
        'settings'   => 'buff_gundong_shadow_color',
    ) ) );

}
add_action( 'customize_register', 'sg_customize_register' );

/**
 * 引入样式
 */
function photos_scripts() {
    //禁止加载默认jq库
    wp_deregister_script('jquery');
    //引入css这个默认放在顶部
    wp_enqueue_style( 'header_css', get_template_directory_uri() . '/css/header.css');
    wp_enqueue_style( 'bootstrap_css', get_template_directory_uri() . '/css/bootstrap.css');
    if(is_home() || is_search() || is_category()) wp_enqueue_style( 'home_css', get_template_directory_uri() . '/css/home.css');
    if(is_single()) wp_enqueue_style( 'single_css', get_template_directory_uri() . '/css/single.css');
    if(is_single()) wp_enqueue_style( 'comments_css', get_template_directory_uri() . '/css/comments.css');

    //引入JS文件 第五个参数为true放在尾部
    wp_enqueue_script( 'jquery', get_template_directory_uri() . '/js/jQuery.js', array(),'',true);
    wp_enqueue_script( 'bootstrap_scripts', get_template_directory_uri() . '/js/bootstrap.js', array( 'jquery' ),'',true);
    wp_enqueue_script( 'pin_scripts', get_template_directory_uri() . '/js/jquery.pin.js', array( 'jquery' ),'',true);
    wp_enqueue_script( 'home_scripts', get_template_directory_uri() . '/js/home.js', array( 'jquery' ),'',true);
}
add_action( 'wp_enqueue_scripts', 'photos_scripts' );