<?php
function get_post_info(){
    //获得评论总数
    $comment_count = get_comment_count(get_the_ID())['all'];
    $comment_string = '<li class="col-md-2"><i class="glyphicon glyphicon-comment"></i> :<span> '.$comment_count.'</span> 评论</li>';

    //获得浏览次数
    if(!$view_count = get_post_meta(get_the_ID(),'_view',true)){
        $view_count = 0;
    }
    $view_string = '<li class="col-md-2"><i class="glyphicon glyphicon-eye-open"></i> :<span> '.$view_count.'</span> 浏览</li>';

    //获取时隔多久发布的
    $time = format_date(get_the_time('U'));
    $time_string = '<li class="col-md-2"><i class="glyphicon glyphicon-time"></i> :<time datetime="'.get_the_time('Y-m-d H:i:s').'"> '.$time.'<div class="hide">'.get_the_time('Y-m-d H:i:s').'</div></time></li>';

    //编辑名
    $author = get_the_author_link();
    $author_string = '<li class="col-md-2"><i class="glyphicon glyphicon-pencil"></i> : '.$author.'</li>';

    return $comment_string.$view_string.$time_string.$author_string;
}