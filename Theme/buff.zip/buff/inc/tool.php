<?php
/**
 * [将时间戳,转换为 多久前发布 的格式]
 * @param  [string] $time [时间戳]
 * @return [string]       [string]
 */
function format_date($time){
    $t=time()-$time;
    $f=array(
        '31536000'=>'年',
        '2592000'=>'个月',
        '604800'=>'星期',
        '86400'=>'天',
        '3600'=>'小时',
        '60'=>'分钟',
        '1'=>'秒'
    );
    foreach ($f as $k=>$v)    {
        if (0 !=$c=floor($t/(int)$k)) {
            return $c.$v.'前';
        }
    }
}

/**
 * //获取文章的第一张图片,用于content-image
 * @param $data 数据
 */
function get_head_image($data){
    $reg = '/img.*src=\"(.*)"\s*alt/';
    preg_match_all($reg,$data,$arr);
    $src = $arr[1][0];
    return $src;
}

/**
 * 获取文章内的第一个视频并且获取封面图
 * @param $data
 */
function get_post_video($data){
    $reg = '/\[video\s*width.*?"(.*?)"\s*poster="(.*?)"/';
    preg_match_all($reg,$data,$arr);
    $location['video'] = $arr[1][0];
    $location['poster'] = $arr[2][0];
    return $location;
}


/**
 *  裁剪字符串长度
 * @param  [type] $string [description]
 * @param  [type] $length [description]
 * @return [type]         [description]
 */
function omitString($string,$length){
    if($string){
        if(mb_strlen($string,'utf-8') > $length){
            $string = mb_substr($string, 0,$length,'utf-8')."...";
        }
    }
    return $string;
}