<?php
//* HEAD
define('HEADER_IMAGE', '%s/images/bg.jpg'); // %s is theme dir uri
define('HEADER_IMAGE_WIDTH', 1800);
define('HEADER_IMAGE_HEIGHT', 400);
define('NO_HEADER_TEXT', true );
define('HEADER_TEXTCOLOR', 'ffffff');

if ( function_exists('add_custom_image_header') ) {
    //add_custom_image_header('header_style', 'admin_header_style');
    add_theme_support( 'custom-header' );
    add_theme_support( 'custom-background');
}

