<!doctype html>
<html lang="en">
<head>
    <meta name="keywords" content="<?php bloginfo('title') ?> ">
    <meta name="description" content="<?php bloginfo('description') ?> ">
    <meta charset="<?php bloginfo('charset'); ?>">
    <title><?php echo bloginfo('title'); ?> | <?php bloginfo('description') ?></title>
    <?php wp_head() ?>
</head>
<body>
<style>
    #head {
        background: rgba(0, 0, 0, 0) url('<?php HEADER_IMAGE(); ?>') no-repeat scroll 50% 50% / cover;
        height: 300px;
    }
    #head_pic:hover{
        box-shadow: 0 0 20px <?php echo get_theme_mod('buff_author_color','#ff4400') ?>;
    }
</style>
<div class="container-fluid" id="head">
    <div class="container">
        <div class="pic container-fluid">
            <a href="/">
                <?php $photos_avatar_image = get_theme_mod('author_pic', get_template_directory_uri().'/assets/images/avatar.jpg' ); ?>
                <?php if(!empty($photos_avatar_image)) : ?>
                    <img src="<?php echo esc_url($photos_avatar_image); ?>" alt="<?php bloginfo('description'); ?>" id="head_pic" class="center-block">
                <?php endif; ?>
            </a>
        </div>
        <div class="container-fluid">
            <input type="hidden" name="description" value="<?php echo esc_attr(bloginfo('description')) ?>">
            <span class="input text-center" id="inputWamp" style="text-shadow: 1px 1px 5px <?php echo get_theme_mod('buff_gundong_shadow_color','#000000') ?>;color: <?php echo get_theme_mod('buff_gundong_color','#ffffff') ?> ;">
                <?php echo esc_attr(bloginfo('name')) ?>
            </span>
        </div>
    </div>
</div>





