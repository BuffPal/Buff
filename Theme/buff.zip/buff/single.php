<?php get_header() ?>
<?php
    global $post;
    the_post();
/*执行自增点击量*/
    $view = get_post_meta(get_the_ID(),'_view',true);
    $view = $view?$view:0;
    update_post_meta(get_the_ID(),'_view',$view+1);
?>
<div class="container" id="main">
    <div class="col-md-8 p0" id="the_content">
        <h2 class="text-center" ><?php esc_attr(the_title()) ?></h2>
        <div class="container-fluid" id="singleContent">
            <?php the_content() ?>
        </div>
        <!--TAG标签-->
        <div class="container-fluid p0" id="singleTag">
            <i class="glyphicon glyphicon-tags" style="color: #666;"></i>　
            <span class="tagspan"><?php the_category('</span><span class="tagspan">') ?></span>
        </div>
        <div class="container-fluid p0">
            <?php  posts_nav_link(',') ?>
        </div>
        <!--评论-->
        <div class="container-fluid p0" id="singleComment">
            <?php comments_template() ?>
        </div>
    </div>
    <div class="col-md-4 bd p0" id="sdb">
        <div class="container-fluid p0" id="sdbchild">
            <?php get_sidebar() ?>
        </div>
    </div>
</div>


<?php get_footer() ?>

