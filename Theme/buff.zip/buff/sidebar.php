<?php if (is_dynamic_sidebar()): ?>
    <?php dynamic_sidebar() ?>
<?php else: ?>
    <!--当前位置-->
    <?php if (!is_home()): ?>
        <div class="bs-callout bs-callout-warning">
            <div class="container-fluid p0 location">
                <i class="glyphicon glyphicon-map-marker"></i>
                <a href='<?php bloginfo('url'); ?>'>首页</a> &#92;
                <?php if (is_category()): ?>
                    <?php single_cat_title() ?>
                <?php elseif (is_search()): ?>
                    <?php echo '<span style="color: #888">当前关键字:</span><font style="color: orangered;"> '.$s.'</font>' ?>
                <?php elseif (is_single()): ?>
                    <?php
                    $cat = get_the_category();
                    $cat = $cat[0];
                    echo '<a href="' . get_category_link($cat) . '">' . $cat->name . '</a> &#92; ';
                    echo '<span>'.omitString(get_the_title(), 15).'</span>';
                    ?>
                <?php elseif (is_page()): ?>
                    <?php the_title() ?>
                <?php elseif (is_404()): ?>
                    <?php echo '404' ?>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!--搜索框-->
    <div class="container-fluid search p0">
        <?php get_search_form() ?>
    </div>

    <!--最新文章-->
    <div class="container-fluid new p0">
        <?php
            $args = array(
                'numberposts' => 5,
                'category' => '',
                'orderby'         => 'post_date',
                'order'           => 'DESC'
            );
            ?>
        <div id="newTitle">最新文章</div>
        <ul>
        <?php
            $posts = get_posts( $args );
            foreach($posts as $post):
                setup_postdata($post);
        ?>
            <li><a href="<?php esc_url(the_permalink()) ?> "><?php echo omitString(esc_attr(get_the_title()),15); ?></a></li>
        <?php endforeach; ?>
        </ul>
    </div>

    <!--热评文章-->
    <div class="container-fluid new p0">
        <?php
            global $wpdb;
            $prefix = $wpdb->prefix;
            $slq = 'SELECT `post_title`,`ID` FROM `'.$wpdb->prefix.'posts` WHERE `comment_status`="open" AND `post_status`="publish" AND `post_type`="post" ORDER BY `comment_count` DESC LIMIT 5';
            $arr = $wpdb->get_results($slq,'ARRAY_A');
        ?>
        <div id="newTitle">热评文章</div>
        <ul>
            <?php
                $posts = get_posts( $args );
                foreach($arr as $v):
            ?>
                <li><a href="<?php esc_url(the_permalink($v['ID'])) ?> "><?php echo omitString(esc_attr($v['post_title']),15); ?></a></li>
            <?php endforeach; ?>
        </ul>
    </div>

    <!--标签云-->
    <?php
        $sql = 'SELECT ter.`name`,ter.`term_id` FROM `'.$prefix.'terms` as ter LEFT JOIN `'.$prefix.'term_taxonomy` as tax ON ter.`term_id` = tax.`term_id` WHERE tax.`taxonomy` = "category" AND ter.`name` <> "未分类" ORDER BY tax.`count` DESC';
        $category = $wpdb->get_results($sql,'ARRAY_A');
        if(count($category) > 0):?>
        <ul id="categoryUl">
    <?php foreach($category as $c):?>
        <li><a href="<?php echo esc_url(get_category_link($c['term_id'])) ?>" style="background-color: rgba(<?php echo rand(180,255) ?>,<?php echo rand(180,255) ?>,<?php echo rand(180,255) ?>,.5);color:rgba(<?php echo rand(0,150) ?>,<?php echo rand(0,150) ?>,<?php echo rand(0,150) ?>,.5);"><?php echo esc_attr($c['name']) ?></a></li>
    <?php endforeach; ?>
        </ul>
    <?php endif;?>
<?php endif; ?>
