<article class="container-fluid">
    <h2 class="post_title text-left">
        <a href="<?php echo esc_url(the_permalink()) ?> ">
            <?php the_title() ?>
        </a>
    </h2>
    <ul class="info">
        <?php  echo get_post_info() ?>
    </ul>
    <div class="box">
        <div class="video-content">
            <?php the_content() ?>
            <div class="video-hr container-fluid">
                <div class="hr">
                    <div class="hrwamp center-block">
                        <div class="hr1">
                            <i class="glyphicon glyphicon-hd-video"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid post_content">
            <?php the_excerpt() ?>
        </div>
        <!--TAG-->
        <div class="container-fluid tagWamp">
            <?php echo get_the_category_list(' '); ?>
        </div>
        <div class="more container-fluid">
            <div class="morebox">
                <a href="#" class="text-center">更多</a>
            </div>
        </div>
        <div class="footer"></div>
    </div>
</article>