jQuery(function(){

jQuery('#revision').click(function(){
    if(confirm('您确定清除吗?')){
        jQuery.post(ajax_object.ajax_url,{
            'action':'rubbish_clear'
        },function($data){
            if($data.status){
                tishi('清理成功!');
                jQuery('#revisionSpan').html('0');
            }else{
                tishi('失败,请稍后重试');
            }
        },'json');
    }
})

jQuery('#draft').click(function(){
    if(confirm('您确定清除吗?')){
        jQuery.post(ajax_object.ajax_url,{
            'action':'draft_clear'
        },function($data){
            if($data.status){
                tishi('清理成功!');
                jQuery('#draftSpan').html('0');
            }else{
                tishi('失败,请稍后重试');
            }
        },'json');
    }
})



})

/**
 * 提示信息
 * @param  {[type]} str [提示内容]
 * @return {[type]}     [description]
 */
function tishi(str){
    jQuery('#fade').stop(true,true);
    jQuery('#fade>span').html(str);
    jQuery('#fade').css({'background':'#ff4400'});
    jQuery('#fade').fadeIn(1000);
    jQuery('#fade').fadeOut(1000);
}

