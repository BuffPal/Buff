<?php
/*
Plugin Name:垃圾管理
Plugin URI: http://localhost
Description:清理数据库多余的垃圾
Version:  1.0
Author: BuffPal
Author URI: http://blog.buff.com
*/

Class buff_rubbishmanage{

    public function __construct()
    {
        //创建一个菜单
        add_action('admin_menu',array($this,'buff_create_menu'));

        //用于ajax引入JS文件
        add_action('admin_enqueue_scripts',array($this,'load_script'));

        //创建AJAX处理方法
        add_action('wp_ajax_rubbish_clear',array($this,'rubbish_clear_function'));
        add_action('wp_ajax_draft_clear',array($this,'rubbish_draft_clear_function'));
}

    //指定页面加载
    public function load_script()
    {
        //获取当前页面URL
        $screen = get_current_screen();

        if(is_object($screen) && $screen->id == 'toplevel_page_rubbish_manage_menu'){
            wp_enqueue_script('buff_ajax',plugins_url('js/buff_ajax.js',__FILE__),array('jquery'));
            wp_localize_script('buff_ajax','ajax_object',array('ajax_url'=>admin_url('admin-ajax.php')));
        }

    }
    
    //AJAX处理删除 修订版本
    public function rubbish_clear_function()
    {
        global $wpdb;
        $sql = 'DELETE FROM `'.$wpdb->prefix.'posts` WHERE `post_type`="revision"';
        if($wpdb->query($sql)){
            echo json_encode(array('status'=>1));
        }else{
            echo json_encode(array('status'=>0));
        }
        wp_die();
    }

    //AJAX处理删除 自动草稿
    public function rubbish_draft_clear_function()
    {
        global $wpdb;
        $sql = 'DELETE FROM `'.$wpdb->prefix.'posts` WHERE `post_status`="auto-draft"';
        if($wpdb->query($sql)){
            echo json_encode(array('status'=>1));
        }else{
            echo json_encode(array('status'=>0));
        }
        wp_die();
    }

    public function buff_create_menu()
    {
        //创建顶级菜单
        add_menu_page(
            'rubbish_manage_menu',
            '垃圾管理',
            'manage_options',
            'rubbish_manage_menu',
            array($this,'buff_menu')
        );
    }

    public function buff_menu()
    {
        global $wpdb;
        $sql = 'SELECT COUNT("id") FROM `'.$wpdb->prefix.'posts` WHERE `post_type`="revision"';
        $rcount = $wpdb->get_var($sql);
        $sql = 'SELECT COUNT("id") FROM `'.$wpdb->prefix.'posts` WHERE `post_status`="auto-draft"';
        $dcount = $wpdb->get_var($sql);
        $count = (int)$rcount + (int)$dcount;
        ?>
            <div class="wrap">
                <style>
                    #fade{
                        position:fixed;
                        left: 40%;
                        top: 38%;
                        width: 200px;
                        height: 40px;
                        background: #fff;
                        z-index: 9999;
                        border-radius: 10px;
                        overflow: hidden;
                        box-shadow: 0px 0px 10px #434343;
                        display: none;
                    }
                    #fade>span{
                        display: block;
                        width: 100%;
                        height: 40px;
                        color: #FFFFFF;
                        text-shadow: 1px 1px 2px #727272;
                        font-size: 1.8rem;
                        text-align: center;
                        line-height: 40px;
                    }
                </style>
                <div id="fade">
                    <span></span>
                </div>
                <h1>垃圾管理</h1>
                <table class="form-table">
                    <tbody>
                    <tr>
                        <th scope="row">
                            <label for="count">垃圾统计</label>
                        </th>
                        <td>
                            <span id="count"><?php echo $count ?></span>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="revision">当前修订版本</label>
                        </th>
                        <td>
                            <span id="revisionSpan"><?php echo $rcount ?></span>
                            <a class="page-title-action" href="javascript:;" id="revision">删除</a>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="">当前自动草稿</label>
                        </th>
                        <td>
                            <span id="draftSpan"><?php echo $dcount ?></span>
                            <a class="page-title-action" href="javascript:;" id="draft">删除</a>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
        <?php
    }



}

new buff_rubbishmanage();