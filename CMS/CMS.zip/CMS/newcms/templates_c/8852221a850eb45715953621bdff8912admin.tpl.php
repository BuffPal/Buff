<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>网站后台</title>
  <link rel="stylesheet" type="text/css" href="../style/admin.css">
</head>
<frameset rows="80px,*" border='0'>
  <frame src="top.php" noresize="true" scrolling="no">
    <frameset cols="150px,*">
    <frame src="../templates/sidebar.html" name="sidebar" noresize="true"  scrolling="no">
    <frame src="main.php" name="map" noresize="true" >
  </frameset>
</frameset>
</html>