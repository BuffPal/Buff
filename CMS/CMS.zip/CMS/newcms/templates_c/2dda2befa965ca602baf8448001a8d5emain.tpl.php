<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" type="text/css" href="../style/admin.css">
</head>
<body id="main">
  <div class="map">
    管理首页&gt;&gt;后台首页
  </div>
</body>
</html>