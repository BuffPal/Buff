<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>测试</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="style/index.css">
  <script type="text/javascript" src="js/tool.js"></script>
  <script type="text/javascript" src="js/index.js"></script>
</head>
<body>
<?php $_tpl->create('header.tpl') ?>


  <div id="content">aa</div>

<?php $_tpl->create('footer.tpl') ?>
<i class="icon-upload backTopHide" id="backTop"></i>
</body>
</html>