<?php 
require dirname(__FILE__).'/init.inc.php';
$_tpl->assign('title','豆腐渣塑料水泥');
$_tpl->display('index.tpl');
 ?>
