<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class links extends Model
{
    protected $fillable= array('name','info','url','order');




}
