﻿
<?php $__env->startSection('content'); ?>
<article>
  <h2 class="title_tj">
    <p>最新<span>文章</span></p>
  </h2>
  <div class="bloglist left">
    <?php if(count($data)>0): ?>
      <?php foreach($data as $v): ?>
        <h3><?php echo e($v->title); ?></h3>
        <figure><img src="<?php echo e(asset($v->thumb)); ?>"></figure>
        <ul>
          <p><?php echo e($v->info); ?></p>
          <a title="<?php echo e($v->title); ?>" href="<?php echo e(url('/article').'/'.$v->aid); ?>" target="_blank" class="readmore">阅读全文>></a>
        </ul>
        <p class="dateview">　<span> <?php echo e(date('Y-m-d',$v->time)); ?></span><span>作者：<?php echo e($v->editor); ?></span><span>所属栏目：[<a href="<?php echo e(url('/lists').'/'.$v->cid); ?>" target="_blank"><?php echo e($v->name); ?></a>]</span></p>
      <?php endforeach; ?>
    <?php endif; ?>
    <?php echo e($data->links()); ?>

  </div>
  <!-- Baidu Button BEGIN -->
  <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare"><a class="bds_tsina"></a><a class="bds_qzone"></a><a class="bds_tqq"></a><a class="bds_renren"></a><span class="bds_more"></span><a class="shareCount"></a></div>
  <script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=6574585" ></script>
  <script type="text/javascript" id="bdshell_js"></script>
  <script type="text/javascript">
    document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
  </script>
  <!-- Baidu Button END -->
  <aside class="right">
    <div class="weather"><iframe width="250" scrolling="no" height="60" frameborder="0" allowtransparency="true" src="http://i.tianqi.com/index.php?c=code&id=12&icon=1&num=1"></iframe></div>
    <div class="news">
    <h3>
      <p>最新<span>文章</span></p>
    </h3>
    <ul class="rank">
      <?php if(count($new) > 0): ?>
        <?php foreach($new as $v): ?>
      <li><a href="<?php echo e(url('/article').'/'.$v->id); ?>" title="Column 三栏布局 个人网站模板" target="_blank"><?php echo e($v->title); ?></a></li>
        <?php endforeach; ?>
      <?php else: ?>
        <li>暂时没有数据</li>
      <?php endif; ?>
     </ul>
    <h3 class="ph">
      <p>点击<span>排行</span></p>
    </h3>
    <ul class="paih">
      <?php if(count($hot5) > 0): ?>
        <?php foreach($hot5 as $v): ?>
          <li><a href="/" title="<?php echo e($v->info); ?>" target="_blank"><?php echo e($v->title); ?></a></li>
        <?php endforeach; ?>
      <?php endif; ?>
    </ul>
    <h3 class="links">
      <p>友情<span>链接</span></p>
    </h3>
    <ul class="website">
      <?php if(count($link) > 0): ?>
        <?php foreach($link as $v): ?>
          <li><a href="<?php echo e($v->url); ?>" target="_blank"><?php echo e($v->name); ?></a></li>
        <?php endforeach; ?>
      <?php else: ?>
        <li>暂时木有数据~</li>
      <?php endif; ?>
    </ul>
    </div>
    </aside>
</article>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>