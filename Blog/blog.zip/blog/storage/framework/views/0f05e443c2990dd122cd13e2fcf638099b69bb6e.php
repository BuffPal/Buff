<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo e(Config::get('web.web_title')); ?> - <?php echo e(Config::get('web.seo_title')); ?></title>
    <meta name="keywords" content="<?php echo e(Config::get('web.web_keyword')); ?>" />
    <meta name="description" content="<?php echo e(Config::get('web.web_description')); ?>" />
    <link href="<?php echo e(asset('Home/css/base.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Home/css/index.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Home/css/new.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('Home/css/style.css')); ?>" rel="stylesheet">
    <!--- 引入 Bootstarp css文件 --->
    <link rel="stylesheet" href="<?php echo e(asset('Public/css/bootstrap.min.css')); ?>">
    <!--[if lt IE 9]>
    <script src="<?php echo e(asset('Home/js/modernizr.js')); ?>"></script>
    <![endif]-->
</head>
<body>
<header>
    <div id="logo"><a href="/"></a></div>
    <nav class="topnav" id="topnav">
        <?php if($navs): ?>
            <?php foreach($navs as $v): ?><a href="<?php echo e($v->url); ?>"><span><?php echo e($v->name); ?></span><span class="en"><?php echo e($v->ename); ?></span></a><?php endforeach; ?>
        <?php endif; ?>
    </nav>
</header>
<div class="banner">
    <section class="box">
        <ul class="texts">
            <p><?php echo e(Config::get('web.p_1')); ?></p>
            <p><?php echo e(Config::get('web.p_2')); ?></p>
            <p><?php echo e(Config::get('web.p_3')); ?></p>
        </ul>

        <div class="avatar"><a href="#" style="background-image: url('<?php echo e(asset('img/buff.jpg')); ?>')"><span><?php echo e(Config::get('web.username')); ?></span></a> </div>
    </section>
</div>
<div class="template">
    <div class="box">
        <h3>
            <p><span>站长</span>推荐 Recommend</p>
        </h3>
        <ul>
            <?php if(count($hot) > 0): ?>
                <?php foreach($hot as $v): ?>
                    <li><a href="<?php echo e(url('/article').'/'.$v->id); ?>"  target="_blank"><img src="<?php echo e(asset($v->thumb)); ?>"></a><span><?php echo e($v->title); ?></span></li>
                <?php endforeach; ?>
            <?php endif; ?>
        </ul>
    </div>
</div>

<?php echo $__env->yieldContent('content'); ?>
<footer>
    <p><?php echo e(Config::get('web.web_footer')); ?>　　<a href="/">网站统计</a></p>
</footer>
</body>
</html>
