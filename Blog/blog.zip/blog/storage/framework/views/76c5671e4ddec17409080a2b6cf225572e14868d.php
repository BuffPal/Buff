
<?php $__env->startSection('content'); ?>
<!--结果集标题与导航组件 开始-->
<div class="result_wrap">
    <div class="result_title text-center">
        <h1>修 改 密 码</h1>
    </div>
</div>
<div style="width: 400px;margin: 0 auto;padding-top: 20px; ">
<?php echo e(Form::open(['url'=>'admin/pass'])); ?>

<!--- 旧密码 Field --->
<div class="form-group">
    <?php echo Form::label('password_o', '旧密码*:'); ?>

    <?php echo Form::password('password_o', ['class' => 'form-control']); ?>

</div>
<!--- 新密码 Field --->
<div class="form-group">
    <?php echo Form::label('password', '新密码*:'); ?>

    <?php echo Form::password('password', ['class' => 'form-control']); ?>

</div>
<!--- 确认密码 Field --->
<div class="form-group">
    <?php echo Form::label('password_confirmation', '确认密码*:'); ?>

    <?php echo Form::password('password_confirmation', ['class' => 'form-control']); ?>

</div>
    <?php echo Form::submit('修改',['class'=>'btn btn-primary btn-block btn-lg']); ?>

    <br>
    <br>
    <a href="<?php echo e(url('admin/index')); ?>" class="btn btn-default btn-block">返回</a>

<?php echo e(Form::close()); ?>

</div>
<?php if($errors->any()): ?>
    <ul class="list-group">
    <?php foreach($errors->all() as $error): ?>
	    <li class="list-group-item list-group-item-danger text-center"><?php echo e($error); ?></li>
    <?php endforeach; ?>
    </ul>
<?php endif; ?>
<?php if(session('msg')): ?>
    <li class="list-group-item list-group-item-danger text-center"><?php echo e(session('msg')); ?></li>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>