﻿
<?php $__env->startSection('content'); ?>
<article class="blogs">
<h1 class="t_nav"><span><?php echo e($cateInfo); ?></span>
    <a href="<?php echo e(url('/')); ?>" class="n1">网站首页</a>
    <?php if(count($category) > 0): ?>
        <?php foreach($category as $k=>$v): ?>
            <a href="<?php echo e(url('/lists').'/'.$v->id); ?>" class="n<?php echo e($k+1); ?>"><?php echo e($v->name); ?></a>
        <?php endforeach; ?>
    <?php endif; ?>
</h1>
<div class="newblog left">
    <?php if(count($data) > 0): ?>
        <?php foreach($data as $v): ?>
           <h2><?php echo e($v->title); ?></h2>
           <p class="dateview"><span>　发布时间:<?php echo e(date('Y-m-d',$v->time)); ?></span><span>作者：<?php echo e($v->editor); ?></span><span>所属栏目：[<a href="<?php echo e(url('/lists').'/'.$v->cid); ?>"><?php echo e($v->name); ?></a>]</span></p>
            <figure><img src="<?php echo e(asset($v->thumb)); ?>"></figure>
            <ul class="nlist">
              <p><?php echo e($v->info); ?>……</p>
              <a title="<?php echo e($v->info); ?>" href="<?php echo e(url('/article').'/'.$v->aid); ?>" target="_blank" class="readmore">阅读全文>></a>
            </ul>
            <div class="line"></div>
        <?php endforeach; ?>
    <?php else: ?>
        <h1>木有数据!</h1>
    <?php endif; ?>

    <?php echo e($data->links()); ?>

</div>
<aside class="right">
   <div class="rnav">
      <ul>
          <?php if(count($child) > 0): ?>
              <?php foreach($child as $k=>$v): ?>
                    <li class="rnav<?php echo e($k+1); ?>"><a href="<?php echo e(url('/lists').'/'.$v->id); ?>"><?php echo e($v->name); ?></a></li>
              <?php endforeach; ?>
          <?php endif; ?>
     </ul>
    </div>
<div class="news">
<h3>
      <p>最新<span>文章</span></p>
    </h3>
    <ul class="rank">
        <?php if(count($newCate) > 0): ?>
            <?php foreach($newCate as $v): ?>
                <li><a href="<?php echo e(url('/article').'/'.$v->id); ?>" title="<?php echo e($v->info); ?>"><?php echo e($v->title); ?></a></li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
    <h3 class="ph">
      <p>点击<span>排行</span></p>
    </h3>
    <ul class="paih">
        <?php if(count($clickData) > 0 ): ?>
            <?php foreach($clickData as $v): ?>
                <li><a href="<?php echo e(url('/article').'/'.$v->id); ?>" title="<?php echo e($v->info); ?>" target="_blank"><?php echo e($v->title); ?></a></li>
            <?php endforeach; ?>
        <?php endif; ?>
    </ul>
    </div>
    <div class="visitors">
      <h3><p>最近访客</p></h3>
      <ul>

      </ul>
    </div>
     <!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare"><a class="bds_tsina"></a><a class="bds_qzone"></a><a class="bds_tqq"></a><a class="bds_renren"></a><span class="bds_more"></span><a class="shareCount"></a></div>
    <script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=6574585" ></script>
    <script type="text/javascript" id="bdshell_js"></script>
    <script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script>
    <!-- Baidu Button END -->
</aside>
</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>