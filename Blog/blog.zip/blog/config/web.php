<?php return array (
  'web_title' => 'Blog个人博客',
  'web_count' => '4564562755',
  'web_status' => '0',
  'web_keyword' => 'Buff,buff,BUFF,PHP,Laravl,Blog',
  'seo_title' => '我是套的模板做的Blog',
  'web_description' => 'A Web Developer Full of Enthusiasm And Passion For Buff!',
  'web_footer' => 'Copyright ©2016[Buff-Blog] Powered By [个人微博] Version 1.0.0  :) 逗你玩!',
  'p_1' => '从这里开始成为现代的 Web开发工程师!',
  'p_2' => 'I am Buff!',
  'p_3' => 'A Web Developer Full of Enthusiasm And Passion',
  'username' => 'Buff',
);