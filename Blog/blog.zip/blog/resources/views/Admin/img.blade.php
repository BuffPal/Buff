<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" href="style/css/ch-ui.admin.css">
	<link rel="stylesheet" href="style/font/css/font-awesome.min.css">
    <script type="text/javascript" src="style/js/jquery.js"></script>
    <script type="text/javascript" src="style/js/ch-ui.admin.js"></script>
</head>
<body>
    <!--面包屑导航 开始-->
    <div class="crumb_warp">
        <!--<i class="fa fa-bell"></i> 欢迎使用登陆网站后台，建站的首选工具。-->
        <i class="fa fa-home"></i> <a href="#">首页</a> &raquo; <a href="#">商品管理</a> &raquo; 添加商品
    </div>
    <!--面包屑导航 结束-->
    
	<!--TAB切换面板和外置按钮组 开始-->
	<div class="result_wrap">
        <div class="result_title">
            <h3>快捷操作</h3>
        </div>
        <div class="result_content">
            <div class="short_wrap">
                <a href="#"><i class="fa fa-plus"></i>新增文章</a>
                <a href="#"><i class="fa fa-recycle"></i>批量删除</a>
                <a href="#"><i class="fa fa-refresh"></i>更新排序</a>
            </div>
        </div>
    </div>

    <div class="result_wrap">
        <ul class="list_pic">
            <li id="pic_xxx"><img src="xxx" style="width:150px;"><span onclick="del_pic(this)"><i class="fa fa-ban"></i></span></li>
            <li id="pic_xxx"><img src="xxx" style="width:150px;"><span onclick="del_pic(this)"><i class="fa fa-ban"></i></span></li>
        </ul>

        <ul class="list_btn">
            <li><input name="pics[]" type="file"> <span onclick="pic_plus(this)"><i class="fa fa-plus-circle"></i></span></li>
            <li><input name="pics[]" type="file"> <span onclick="pic_minus(this)"><i class="fa fa-minus-circle"></i></span></li>
        </ul>
    </div>
    <!--TAB切换面板和外置按钮组 结束-->

</body>
</html>