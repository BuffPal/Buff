<?php
return array(
	 //自动登录保存时间
  'AUTO_LOGIN_TIME' => time()+3600*24*7,    //一个星期
  //URL重写
  'URL_MODEL' => '2',//RUL模式 2位PATHINFO
  'CACHE_MAX_TIME_HOTVIDEO'=>3600*24, //前台大家都在看视频缓存一天

  'MUSIC_LISTS_SIZE' => 15,//视频列表页,没页最大分页条数
);