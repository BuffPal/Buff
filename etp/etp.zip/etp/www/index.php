<?php 
define('APP_PATH','./etp/');
define('APP_DEBUG', True);
define('BIND_MODULE','Index');//选择项目的模块
include 'ThinkPHP/ThinkPHP.php';

 ?>