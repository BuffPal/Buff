<?php 
define('APP_PATH','./etp/');
define('APP_DEBUG', true);
define('BIND_MODULE','Admin');//选择项目的模块
include 'ThinkPHP/ThinkPHP.php';

 ?>