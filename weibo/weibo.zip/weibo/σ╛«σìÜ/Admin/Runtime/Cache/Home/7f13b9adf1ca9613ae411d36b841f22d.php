<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" type="text/css" href="/weibo/Public/css/admin.css">
</head>
<body id="sidebar">
  <dl>
    <dt>会员管理</dt>
    <dd><a href="../admin/user.php?action=show" target="map">查看会员列表</a></dd>
  </dl>
</body>
</html>