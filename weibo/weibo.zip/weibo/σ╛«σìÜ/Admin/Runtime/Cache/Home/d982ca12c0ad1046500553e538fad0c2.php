<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" type="text/css" href="/weibo/Public/css/admin.css">
</head>
<body id="sidebar">
  <dl>
    <dt>系统管理</dt>
    <dd><a href="../admin/system.php" target="map">系统配置</a></dd>
  </dl>
</body>
</html>