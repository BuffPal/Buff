<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>
  <link rel="stylesheet" type="text/css" href="/weibo/Public/css/admin.css">
</head>
<body id="sidebar">
  <dl>
    <dt>内容管理</dt>
    <dd><a href="../admin/nav.php?action=show" target="map">设置网站导航</a></dd>
    <dd><a href="../admin/content.php?action=show" target="map">查看文档列表</a></dd>
    <dd><a href="../admin/rotation.php?action=show" target="map">轮播图设置</a></dd>
    <dd><a href="../admin/comment.php?action=show" target="map">文档评论管理</a></dd>
  </dl>
</body>
</html>