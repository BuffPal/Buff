<?php 
  define('APP_NAME', 'Index');
  define('APP_PATH','./Index/');
  define('APP_DEBUG', true);
  require './ThinkPHP/ThinkPHP.php';


 ?>