<?php

	define('APP_NAME', 'Admin');
	define('APP_PATH', './Admin/');
	define('APP_DEBUG', false);
	require './ThinkPHP/ThinkPHP.php';
?>